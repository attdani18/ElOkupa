# SargentoBananoBot

1. Subí `index.js`, `package.json` y `.gitignore` a la raíz de tu repositorio GitHub.
2. Si conservás un `package-lock.json` antiguo, eliminá ese archivo para evitar el error de `npm ci`. Lo ideal es regenerarlo posteriormente con `npm install` y subirlo.
3. En Railway configurá `DISCORD_TOKEN` y `VOICE_CHANNEL_ID` como variables privadas.
4. En Railway, Build Command: `npm install`; Start Command: `npm start`.
5. El bot necesita permisos Ver canal y Conectar en el canal de voz. Habilitá Message Content Intent en Discord Developer Portal para las respuestas por palabras clave.
6. Mantené el servicio de Railway siempre encendido, con política de reinicio si falla. La conexión puede interrumpirse por caídas de Railway/Discord; el bot reintenta al estar activo.

Nunca publiques el token en GitHub.
